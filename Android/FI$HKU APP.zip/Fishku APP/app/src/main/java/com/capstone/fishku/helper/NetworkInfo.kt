package com.capstone.fishku.helper

import com.capstone.fishku.BuildConfig


object NetworkInfo {
    const val API_URL = BuildConfig.API_URL
}