package com.capstone.fishku.data.model

import com.google.gson.annotations.SerializedName

data class Ordering(

	@field:SerializedName("Ordering")
	val ordering: List<OrderingItem?>? = null
)

data class OrderingItem(

	@field:SerializedName("time_order")
	val timeOrder: Any? = null,

	@field:SerializedName("id_order")
	val idOrder: Int? = null,

	@field:SerializedName("address")
	val address: String? = null,

	@field:SerializedName("id_cart")
	val idCart: Int? = null,

	@field:SerializedName("id_fisher")
	val idFisher: Int? = null
)
